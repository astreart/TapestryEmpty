function init(){
	$('a.ajax').click(loadPage);//For
	
	collapsibleFieldsets('collapsible');
	
	$('.datepicker').datepicker({
			language: 'bg', 
			weekStart: 1, 
			format: 'dd.mm.yyyy'
	}).on('changeDate', function(ev){
		$('.datepicker').datepicker('hide');
	});
}

function loadPage(){
	if(this.href){
		link = this.href;
	}else{
		link = this.location.href;
	}
	var hash = link.substring(link.indexOf('#')+1);
	var type = hash.substring(hash.lastIndexOf('.')+1);
	
	if(!hash){
		return;
	}
	
	if(type == 'html'){
		$.ajax({
			url: 'mockups/' + hash,
			'beforeSend' : function(xhr) {
				xhr.overrideMimeType('text/html;charset=windows-1251');
			},
			success: function(data){
				$('#content').html(data);
				init();
			}
		});
		
	}else{
		var imgTag = '<img style="float:right; width: 900px" src="mockups/' + hash + '.png"/>';
		$('#content').html(imgTag);
	}
}