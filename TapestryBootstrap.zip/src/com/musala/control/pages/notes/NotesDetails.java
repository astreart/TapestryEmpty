package com.musala.control.pages.notes;

public class NotesDetails {

}