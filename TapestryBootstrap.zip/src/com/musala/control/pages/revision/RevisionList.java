package com.musala.control.pages.revision;

public class RevisionList {

}