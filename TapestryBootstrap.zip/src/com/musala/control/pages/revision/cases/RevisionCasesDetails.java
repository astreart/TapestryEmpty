package com.musala.control.pages.revision.cases;

public class RevisionCasesDetails {

}