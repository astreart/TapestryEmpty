package com.musala.control.pages.revision;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.apache.tapestry5.Block;
import org.apache.tapestry5.annotations.Persist;

public class RevisionDetails {
	
	@Inject
	private Block documents, processes, auditlog, notes;
	
//	public enum Tabs{
//		DOCUMENTS("documents", documents),
//		PROCESSES("processes", processes),
//		AUDITLOG("auditlog", auditlog),
//		NOTES("notes", notes)
//		
//		public String name;
//		public Block block;
//		
//		Tabs(String name, Block block){
//			this.name= name;
//			this.block = block;
//		}
//	}

//	public Map<String,Block> TABS = new HashMap<String, Block>();
	
	@Persist
	private Block activeTab;
	
	void onActivate(String tab){
		
		if("documents".equals(tab)){
			this.activeTab = documents;
		}else if("processes".equals(tab)){
			this.activeTab = processes;
		}else if("auditlog".equals(tab)){
			this.activeTab = notes;
		}else if("auditlog".equals(tab)){
			this.activeTab = auditlog;
		}else{
			this.activeTab = documents;
		}
	}
  
	public Block getActiveTab(){
		return activeTab;
	}
	
	public boolean isActive(String tab){
		boolean isActive = activeTab.toString().indexOf(tab)>-1;
		return isActive;
	}
	
	
	public String getActive(String tab){
		return isActive(tab)?"active":"";
	}
}
