package com.musala.control.pages.revision.plan;

public class Activity {

}