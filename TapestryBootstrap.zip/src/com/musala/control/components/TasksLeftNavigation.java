package com.musala.control.components;

public class TasksLeftNavigation {

}
