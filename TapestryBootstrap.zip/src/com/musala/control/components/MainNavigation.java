package com.musala.control.components;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.Block;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

/**
 * Main navigation used in the system
 * 
 * @author emil.alkalay
 *
 */
public class MainNavigation {
	
   @Property
   @Parameter(required = true, defaultPrefix = BindingConstants.LITERAL)
   private String currentPageId;
   
   @Property
   @Parameter(defaultPrefix = BindingConstants.LITERAL)
   private Block leftNavigation;
   
}