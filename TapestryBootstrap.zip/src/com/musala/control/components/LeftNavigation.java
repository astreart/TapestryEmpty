package com.musala.control.components;

public class LeftNavigation {

}