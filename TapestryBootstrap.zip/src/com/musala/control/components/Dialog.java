package com.musala.control.components;

import org.apache.tapestry5.annotations.Property;

public class Dialog {
	
	@Property
	private String url;

	public Dialog() {
		
		
	}

}