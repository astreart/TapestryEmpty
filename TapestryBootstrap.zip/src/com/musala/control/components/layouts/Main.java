package com.musala.control.components.layouts;

import org.apache.tapestry5.BindingConstants;
import org.apache.tapestry5.Block;
import org.apache.tapestry5.annotations.Import;
import org.apache.tapestry5.annotations.Parameter;
import org.apache.tapestry5.annotations.Property;

@Import(stylesheet = { "context:css/bootstrap.css", "context:css/bootstrap-editable.css", 
								"context:css/bootstrap-ext.css", "context:css/main.css" },
		 library = {"context:js/jquery-1.9.1.js", "context:js/bootstrap.js",
						"context:js/bootstrap-editable.js", "context:js/bootstrap-ext.js", "context:js/main.js"})
public class Main {
	
	public Main() {
		
	}
	
   /** The page title, for the <title> element and the <h1> element. */
   @Property
   @Parameter(required = true, defaultPrefix = BindingConstants.LITERAL)
   private String title;

   @Property
   @Parameter(required = false, defaultPrefix = BindingConstants.LITERAL)
   private String currentPageId;
   
   @Property
   @Parameter(defaultPrefix = BindingConstants.LITERAL, value="LeftNavigation")
   private Block leftNavigation;
}
