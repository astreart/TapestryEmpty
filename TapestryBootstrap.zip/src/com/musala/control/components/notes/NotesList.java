package com.musala.control.components.notes;

public class NotesList {

	
}
