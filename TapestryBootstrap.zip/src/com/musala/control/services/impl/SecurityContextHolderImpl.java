package com.musala.control.services.impl;

import com.musala.control.services.SecurityContextHolder;

public class SecurityContextHolderImpl implements SecurityContextHolder {

	@Override
	public String getName() {
		return "���� ������";
	}

	@Override
	public String getId() {
		return "RO201230";
	}

	@Override
	public String getUsername() {
		return "ivani";
	}

}
