package com.musala.control.services;

import org.apache.tapestry5.SymbolConstants;
import org.apache.tapestry5.ioc.MappedConfiguration;
import org.apache.tapestry5.ioc.ServiceBinder;
import org.apache.tapestry5.ioc.annotations.Contribute;
import org.apache.tapestry5.ioc.services.ApplicationDefaults;
import org.apache.tapestry5.ioc.services.SymbolProvider;

import com.musala.control.services.impl.SecurityContextHolderImpl;

public class ControlAppModule {

	@Contribute(SymbolProvider.class)
	@ApplicationDefaults
	public static void contributeApplicationDefaults(MappedConfiguration<String, String> configuration) {
		configuration.add(SymbolConstants.MINIFICATION_ENABLED, "false");
		configuration.add(SymbolConstants.CHARSET, "windows-1251");
	}

	public static void bind(ServiceBinder binder) {
		binder.bind(SecurityContextHolder.class, SecurityContextHolderImpl.class);
	}
	
//	public boolean equals(Object object){
//		return super.equals(object);
//	}
//	
//	public String toString(){
//		return super.toString();
//	}
}
