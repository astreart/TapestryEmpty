package com.musala.control.services;

public interface SecurityContextHolder {
	
	public String getName();
	
	public String getId();
	
	public String getUsername();

}
